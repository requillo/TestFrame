<?php 
// $plugin['name'] = 'Intake';
$plugin['icon'] = 'glyphicons glyphicons-notes';
$plugin['author'] = 'Requillo';
$plugin['author_link'] = 'http://www.requillo.com';
$plugin['version'] = 3.1;
$plugin['desc'] = 'This is to register all donations';
// Add stylesheets files relative where the plugins is
$enqueue->style('assets/css/donations.css?ver=12');
$enqueue->script('assets/js/donations.js?ver=12','footer');

$nav->sub('index',__('All Donations','donations'));
$nav->sub('add-first',__('Add','donations'));
$nav->sub('donations-assets',__('Donations Assets','donations'));
$nav->sub('settings',__('Settings','donations'));