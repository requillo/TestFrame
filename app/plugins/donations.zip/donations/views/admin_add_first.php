<?php 
$form->create(array('id'=>'donations', 'file-upload' => true, 'attribute' => 'autocomplete="off"'));
?>
<div class="container-fluid"> 
    <div class="row">
      <div class="col-lg-12 col-md-12 text-right">
       <?php $form->input('save',array('value' => __('Next','donations'),'type'=>'submit','class'=>'bsave btn btn-success','no-wrap' => true)) ?>
       <?php // echo $html->admin_link(__('Cancel','clients'),'clients/view/'.$Client['id'].'/', array('class'=>'bclose btn btn-danger')) ?>
       <input class="main_link hide" value="<?php echo url();?>">
      </div>
    </div>  
</div>
<?php if(!empty($Person)): ?>
<div class="container-fluid"> 
	<div class="panel panel-default">
		<div class="panel-heading"><h3><?php echo __('Applicant information','donations') ?></h3></div>
		<div class="panel-body">
		  <div class="row">
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('first_name',array('label'=>__('First name','donations'),'value' => $Person['first_name'], 'attribute' =>'disabled')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('last_name',array('label'=>__('Last name','donations'),'value' => $Person['last_name'], 'attribute' =>'disabled')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('id_number',array('label'=>__('ID Number','donations'),'value' => $Person['id_number'], 'attribute' =>'disabled')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_telephone',array('label'=>__('Telephone','donations'),'value' => $Person['person_telephone'])); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_address',array('label'=>__('Address','donations'),'value' => $Person['person_address'])); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_email',array('label'=>__('E-mail','donations'),'value' => $Person['person_email'])); ?>
			</div>
		  </div>
		  <div class="overwrite hide alert alert-success">
		  	<h3><?php echo __('Check the box to add a new person!','donations') ?></h3>
		  		<?php
		  		$sametext = __('Not the same person as shown below!','donations'); 
		  		$form->input('notsame',array('value' => 1, 'type' => 'checkbox','class' => 'flat ','label'=>$sametext , 'label-pos' => 'after')); 
		  		?>
		  </div>
		  <?php if(!empty($Foundations)): ?>
		 
		  <div class="similar-persons">
		  <h3 class="text-danger"><?php echo __('We found Company, Organization, School or Foundation associated with this person!') ?></h3>
		  </div>
		  <div class="row">
		  <div class="sim_results">
		  		<?php foreach ($Foundations as $Foundation) { ?>
		  		<?php 
		  			$id = $Foundation['info']['id'];
		  			$name = $Foundation['info']['foundation_name'];
		  			$address = $Foundation['info']['foundation_address'];
		  			$email = $Foundation['info']['foundation_email'];
		  			$phone = $Foundation['info']['foundation_telephone'];
		  			if(empty($address)){
		  				$address = '.....';
		  			}
		  			if(empty($email)){
		  				$email = '.....';
		  			}
		  			if(empty($phone)){
		  				$phone = '.....';
		  			}
		  		?>
		  			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 spec">
		  				<div class="overwrite alert alert-success">
		  					<label for="found-<?php echo $Foundation['info']['id'];?>">
		  					<input type="checkbox" name="data[foundation_id]" id="found-<?php echo $id;?>" class="flat spec_check hasfd" value="<?php echo $id;?>">
		  					<span><?php echo  $name;?></span>
		  					<hr>
		  					<div><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo  $address;?></div>
		  					<div><i class="fa fa-phone-square" aria-hidden="true"></i> <?php echo  $phone;?></div>
		  					<div><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo  $email;?></div>
		  					</label>
						</div>
						
		  			</div>
		  		<?php } ?>
		  	</div>
		  </div>
		<?php endif;?>

		</div>
	</div>
</div>

<?php else: ?>

<div class="container-fluid"> 
	<div class="panel panel-default">
		<div class="panel-heading"><h3><?php echo __('Applicant information','donations') ?></h3></div>
		<div class="panel-body">
		  <div class="row">
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('first_name',array('label'=>__('First name','donations').' <span class="text-danger">*</span>')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('last_name',array('label'=>__('Last name','donations').' <span class="text-danger">*</span>')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('id_number',array('label'=>__('ID Number','donations').' <span class="text-danger">*</span>')); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_telephone',array('label'=>__('Telephone','donations'))); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_address',array('label'=>__('Address','donations'))); ?>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('person_email',array('label'=>__('E-mail','donations'))); ?>
			</div>
		  </div>
		  <div class="sim_id hide">
		  		<?php $form->input('same',array('label'=>__('Same persons','donations'))); ?>
		  		<?php $form->input('per_sim',array('label'=>__('Perfect similar','donations'))); ?>
		  		<?php $form->input('mix_name',array('label'=>__('Mix Names','donations'))); ?>
		  </div>
		  <div class="overwrite hide alert alert-success">
		  	<h3><?php echo __('Check the box to add a new person!','donations') ?></h3>
		  		<?php
		  		$sametext = __('Not the same person as shown below','donations'); 
		  		$form->input('notsame',array('value' => 1, 'type' => 'checkbox','class' => 'flat sp_checker','label'=>$sametext , 'label-pos' => 'after')); 
		  		?>
		  </div>
		  <div class="similar-persons hide">
		  	<h3 class="text-danger"><?php echo __('We found similar persons, please select a person below!') ?></h3>
		  	<div class="sim_results"></div>
		  </div>
		</div>
	</div>
</div>
<?php endif; ?>
<div class="container-fluid foundation-add"> 
	<div class="panel panel-default">
		<div class="panel-heading"><h3><?php echo __('Company, Organization, School or Foundation information','donations'); ?></h3></div>
		<div class="panel-body">
		  <div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
			<?php 
			$c_name = __('Name (Company, Organization, School, Foundation etc.)'.' <span class="text-danger">*</span>','donations');
			$form->input('foundation_name',array('label'=>$c_name)); 
			?>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('foundation_telephone',array('label'=>__('Telephone','donations'))); ?>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('foundation_address',array('label'=>__('Address','donations'))); ?>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
				<?php $form->input('foundation_email',array('label'=>__('E-mail','donations'))); ?>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="f_overwrite alert alert-success hide">
		  	<h3><?php echo __('Check the box to add a new Company, Organization etc.','donations') ?></h3>
	  		<?php
	  		// $form->input('same',['label'=>__('Same persons','donations')]);
	  		$form->input('fsame',array('class' => 'hide'));
	  		$form->input('fper_sim', array('class' => 'hide'));
	  		$sametext = __('Not the same Company, Organisation etc. as shown below!','donations'); 
	  		$form->input('f_notsame',array('value' => 1 , 'type' => 'checkbox','class' => 'flat spec_check owfs','label'=>$sametext , 'label-pos' => 'after')); 
	  		?>
		  	</div>
			</div>
			</div>
			<h3 class="text-danger found_sim_head hide"><?php echo __('We found similar results, please check','donations'); ?></h3>
			<div class="row">
			<div class="sim_foundation_results">
				
			</div>
		  </div>
		</div>
	</div>
</div>
<div class="showpop"></div>

<?php
$form->close();
?>
<script type="text/javascript">
	$('body').on('ifChecked','input[type="checkbox"]', function() {
   		$('input.spec_check').not(this).iCheck('uncheck'); 
	});
	var rnm = '';
	$('body').on('ifChecked', 'input.res_found_check', function(event){
		rnm =  $(this).closest('.overwrite').find('label span').text();
	});

	$('body').on('ifUnchecked', 'input.res_found_check', function(event){
		 rnm = '';
	});

	$('body').on('ifChecked', 'input.spec_check', function(event){
		rnm =  $(this).closest('.overwrite').find('label span').text();
	});

	$('body').on('ifUnchecked', 'input.spec_check', function(event){
		rnm = '';
	});

	$('#input-save').on('click', function(e){
		e.preventDefault();
		$('input').removeClass('form-error');
		$('.showpop').html('');
		var nf = $('#input-first_name').val();
		var nfe = $('#input-first_name');
		var nl = $('#input-last_name').val();
		var nle = $('#input-last_name');
		var sid = $('#input-id_number').val();
		var side = $('#input-id_number');
		var t = $('#input-person_telephone').val();
		var a = $('#input-person_address').val();
		var e = $('#input-person_email').val();
		var fnn = $('#input-foundation_name').val();
		var ft = $('#input-foundation_telephone').val();
		var fa = $('#input-foundation_address').val();
		var fe = $('#input-foundation_email').val();
		var h = '<div class="poptitle"><?php echo __("Please check if the information is correct!", "donations");?></div>';
		var dinf = '<div class="text-bold"><?php echo __("Applicant information", "donations");?></div>';
		var btn1 = '<a class="btn btn-success btn-go pull-right"><?php echo __("Yes information is correct", "donations");?></a>';
		var btn2 = '<a class="btn btn-danger btn-cancel pull-left"><?php echo __("I need to edit information", "donations");?></a>';
		var btns = '<div class="btn-holder">'+btn2+btn1+'</div>';
		if(nf.replace(/\s+/g, '') != '') {
			nf = '<div>'+'<?php echo __("First name", "donations");?>: '+nf+'</div>';
		} else {
			nf = '';
			nfe.addClass('form-error');
		}
		if(nl.replace(/\s+/g, '') != '') {
			nl = '<div>'+'<?php echo __("Last name", "donations");?>: '+nl+'</div>';
		} else {
			nl = '';
			nle.addClass('form-error');
		}
		if(sid.replace(/\s+/g, '') != '') {
			sid = '<div>'+'<?php echo __("ID Number", "donations");?>: '+sid+'</div>';
		} else {
			sid = '';
			side.addClass('form-error');
		}
		if(t.replace(/\s+/g, '') != '') {
			t = '<div>'+'<?php echo __("Telephone", "donations");?>: '+t+'</div>';
		} else {
			t = '';
		}
		if(a.replace(/\s+/g, '') != '') {
			a = '<div>'+'<?php echo __("Address", "donations");?>: '+a+'</div>';
		} else {
			a = '';
		}
		if(e.replace(/\s+/g, '') != '') {
			e = '<div>'+'<?php echo __("E-mail", "donations");?>: '+e+'</div>';
		} else {
			e = '';
		}
		if(fnn.replace(/\s+/g, '') != '' || rnm != '') {
			hfnn = '<div class="text-bold"><?php echo __("Company, Organisation, School, Foundation etc. information", "donations");?></div>';
			fnn = '<div>'+'<?php echo __("Name", "donations");?>: '+fnn+'</div>';
		} else {
			fnn = '';
			hfnn = '';
		}
		if(ft.replace(/\s+/g, '') != '') {
			ft = '<div>'+'<?php echo __("Telephone", "donations");?>: '+ft+'</div>';
		} else {
			ft = '';
		}
		if(fa.replace(/\s+/g, '') != '') {
			fa = '<div>'+'<?php echo __("Address", "donations");?>: '+fa+'</div>';
		} else {
			fa = '';
		}
		if(fe.replace(/\s+/g, '') != '') {
			fe = '<div>'+'<?php echo __("E-mail", "donations");?>: '+fe+'</div>';
		} else {
			fe = '';
		}

		if(rnm != '') {
			fnn = rnm;
			ft = '';
			fa = '';
			fe = '';
		}
			

		if(nf != '' && nl != '' && sid != '') {

			$('.showpop').append('<div class="load-overlay bg-dark"></div><div class="popwrapper">'+h+dinf+nf+nl+sid+t+a+e+hfnn+fnn+ft+fa+fe+btns+'</div>');
		}
	});
	$('body').on('click','.btn-cancel',function(){
		$('.showpop').html('');

	});
	$('body').on('click','.btn-go',function(){
		$('#donations').submit();
	});
</script>