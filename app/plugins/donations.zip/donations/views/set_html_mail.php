<?php 
echo $test;