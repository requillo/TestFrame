
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dashboard_graph">

                <div class="row x_title">
                  <div class="col-md-6">
                    <h3><?php echo __('All Donations','donations'); ?> <small></small></h3>
                  </div>
                  <div class="col-md-6">
                    <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                      <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                      <span></span> <b class="caret"></b>
                    </div>
                  </div>
                </div>

                <div class="col-md-9 col-sm-9 col-xs-12">
                  <div id="chart_plot_01" class="demo-placeholder"></div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12 bg-white">
                  <div class="x_title">
                    <h2><?php echo __('All Donations','donations'); ?></h2>
                    <div class="clearfix"></div>
                  </div>

                  <div class="col-md-12 col-sm-12 col-xs-6">
                    <div>
                      <p><?php echo __('Approved donation','donations'); ?></p>
                      <div class="">
                        <div class="progress progress_sm" >
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="<?php echo $totals['all']['perc']?>"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p><?php echo __('Cash Donations','donations'); ?></p>
                      <div class="">
                        <div class="progress progress_sm" >
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="<?php echo $totals['cash']['perc']?>"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-6">
                    <div>
                      <p><?php echo __('Product Donations','donations'); ?></p>
                      <div class="">
                        <div class="progress progress_sm" >
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="<?php echo $totals['prod']['perc']?>"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p><?php echo __('Service Donations','donations'); ?></p>
                      <div class="">
                        <div class="progress progress_sm">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="<?php echo $totals['service']['perc']?>"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                <div class="clearfix"></div>
              </div>
            </div>

          </div>
<pre>
<?php // print_r($totals); ?>
</pre>
<script type="text/javascript">

  <?php foreach ($data as $key => $value): ?>
   var <?php echo $key ?> = [
       <?php foreach ($value as $v){ ?>
         [<?php echo strtotime($v['date']).'000';?>, <?php echo $v['amount']?>],
       <?php } ?>
   ]; 
  <?php endforeach ?>

  function gd(year, month, day) {
    return new Date(year, month - 1, day).getTime();
  }

  var randNum = function() {
    return (Math.floor(Math.random() * (1 + 40 - 20))) + 20;
  };
  var chart_plot_02_data = [];
  for (var i = 0; i < 30; i++) {
      chart_plot_02_data.push([new Date(Date.today().add(i).days()).getTime(), randNum() + i + i + 10]);
    }
  var arr_data1 = [
      [gd(2018, 4, 9), 2500],
      [gd(2018, 4, 10), 4500],
      [gd(2018, 4, 11), 5000],
      [gd(2018, 4, 13), 1500],
      [gd(2018, 4, 16), 1000],
      [gd(2018, 4, 17), 500],
      [gd(2018, 4, 18), 3800],
      [gd(2018, 4, 19), 4200],
      [gd(2018, 4, 20), 800]
    ];
  var arr_data2 = [
      [gd(2018, 4, 9), 1200],
      [gd(2018, 4, 13), 1000],
      [gd(2018, 4, 16), 1000],
      [gd(2018, 4, 17), 250],
      [gd(2018, 4, 19), 1200],
      [gd(2018, 4, 20), 400]
    ];
  var arr_data3 = [
      [gd(2018, 4, 9), 1300],
      [gd(2018, 4, 10), 4500],
      [gd(2018, 4, 11), 4000],
      [gd(2018, 4, 13), 500],
      [gd(2018, 4, 18), 500]
    ];
   var arr_data4 = [
      [gd(2018, 4, 11), 1000],
      [gd(2018, 4, 17), 250],
      [gd(2018, 4, 18), 3300],
      [gd(2018, 4, 19), 3000],
      [gd(2018, 4, 20), 400]
    ];
  var chart_plot_01_settings = {
         axisLabels: {
                show: true
            },
            grid: {
                show: true,
                aboveData: true,
                color: "#3f3f3f",
                labelMargin: 10,
                axisMargin: 0,
                borderWidth: 0,
                borderColor: null,
                minBorderMargin: 5,
                clickable: true,
                hoverable: true,
                autoHighlight: true,
                mouseActiveRadius: 100
              },
              tooltip: true,
      tooltipOpts: {
        content: "%s: %y.0",
        xDateFormat: "%d/%m",
      shifts: {
        x: -30,
        y: -50
      },
      defaultTheme: false
      },
          series: {
            lines: {
              show: false,
              fill: true
            },
            splines: {
              show: true,
              tension: 0.4,
              lineWidth: 1,
              fill: 0.4
            },
            points: {
              radius: 0,
              show: true
            },
            shadowSize: 2
          },
          colors: ["rgba(38, 185, 154, 0.38)", "rgba(3, 88, 106, 0.38)"],
          xaxis: {
            tickColor: "rgba(51, 51, 51, 0.06)",
            mode: "time",
            tickSize: [1, "day"],
            //tickLength: 10,
            axisLabel: "Date",
            axisLabelUseCanvas: true,
            axisLabelFontSizePixels: 12,
            axisLabelFontFamily: 'Verdana, Arial',
            axisLabelPadding: 10
          },
          yaxis: {
            ticks: 8,
            tickColor: "rgba(51, 51, 51, 0.06)",
          },
          
        }

  var chart_plot_02_settings = {
        axisLabels: {
            show: true
        },
      grid: {
        show: true,
        aboveData: true,
        color: "#3f3f3f",
        labelMargin: 10,
        axisMargin: 0,
        borderWidth: 0,
        borderColor: null,
        minBorderMargin: 5,
        clickable: true,
        hoverable: true,
        autoHighlight: true,
        mouseActiveRadius: 100
      },
      series: {
        lines: {
          show: true,
          fill: true,
          lineWidth: 2,
          steps: false
        },
        points: {
          show: true,
          radius: 4.5,
          symbol: "circle",
          lineWidth: 3.0
        }
      },
      legend: {
        position: "ne",
        margin: [0, -25],
        noColumns: 0,
        labelBoxBorderColor: null,
        labelFormatter: function(label, series) {
          return label + '&nbsp;&nbsp;';
        },
        width: 40,
        height: 1
      },
      colors: ['#7c5623', '#54b300', '#308dff', '#ba7200', '#ba7200', '#5a8022', '#2c7282'],
      shadowSize: 0,
      tooltip: true,
      tooltipOpts: {
        content: '<div class="gtip"> %s: %y <br> %x</div>',
        xDateFormat: "%a %d %b %Y",
      shifts: {
        x: -50,
        y: -80
      },
      defaultTheme: false
      },
      yaxis: {
        min: 0
      },
      xaxis: {
        mode: "time",
        minTickSize: [1, "day"],
       // timeformat: "%d/%m/%y",
       // min: chart_plot_02_data[0][0],
       // max: chart_plot_02_data[20][0]
      }
    };  
  
    var chart_plot_03_settings = {
      series: {
        curvedLines: {
          apply: true,
          active: true,
          monotonicFit: true
        }
      },
      colors: ["#26B99A"],
      grid: {
        borderWidth: {
          top: 0,
          right: 0,
          bottom: 1,
          left: 1
        },
        borderColor: {
          bottom: "#7F8790",
          left: "#7F8790"
        }
      }
    };
        

  if ($("#chart_plot_01").length){
      console.log('Plot1');      
      $.plot( $("#chart_plot_01"), [ { data: all, label: "All Approved donation"},{ data: cash, label: "Cash Donations"},{ data: prod, label: "Product Donations"},{ data: service, label: "Service Donations"}],  chart_plot_02_settings );
    }


    function init_daterangepicker() {

      if( typeof ($.fn.daterangepicker) === 'undefined'){ return; }
      console.log('init_daterangepicker');
    
      var cb = function(start, end, label) {
        console.log(start.toISOString(), end.toISOString(), label);
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
      };

      var optionSet1 = {
        startDate: moment().subtract(29, 'days'),
        endDate: moment(),
        minDate: '01/01/2012',
        maxDate: '<?php echo date('m/d/Y'); ?>', 
        dateLimit: {
        days: 60
        },
        showDropdowns: true,
        showWeekNumbers: true,
        timePicker: false,
        timePickerIncrement: 1,
        timePicker12Hour: true,
        ranges: {
        //'Today': [moment(), moment()],
        //'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        opens: 'left',
        buttonClasses: ['btn btn-default'],
        applyClass: 'btn-small btn-primary',
        cancelClass: 'btn-small',
        format: 'MM/DD/YYYY',
        separator: ' to ',
        locale: {
        applyLabel: 'Submit',
        cancelLabel: 'Clear',
        fromLabel: 'From',
        toLabel: 'To',
        customRangeLabel: 'Custom',
        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        firstDay: 1
        }
      };
      
      $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
      $('#reportrange').daterangepicker(optionSet1, cb);
      $('#reportrange').on('show.daterangepicker', function() {
        console.log("show event fired");
      });
      $('#reportrange').on('hide.daterangepicker', function() {
        console.log("hide event fired");
      });
      $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
        console.log("apply event fired, start/end dates are " + picker.startDate.format('MMMM D, YYYY') + " to " + picker.endDate.format('MMMM D, YYYY'));
      });
      $('#reportrange').on('cancel.daterangepicker', function(ev, picker) {
        console.log("cancel event fired");
      });
      $('#options1').click(function() {
        $('#reportrange').data('daterangepicker').setOptions(optionSet1, cb);
      });
      $('#options2').click(function() {
        $('#reportrange').data('daterangepicker').setOptions(optionSet2, cb);
      });
      $('#destroy').click(function() {
        $('#reportrange').data('daterangepicker').remove();
      });
   
    }

    init_daterangepicker();

          </script>